import { DbUser, UserToResponse } from '../interfaces/typings';

export const userToResponse = (user: DbUser): UserToResponse => ({
    userId: user.user_id,
    login: user.loginname,
    age: user.age
});

export const usersToResponse = (users: DbUser[]): UserToResponse[] => users.map(user => userToResponse(user));
