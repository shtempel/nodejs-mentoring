export const ROUTES = {
    userRoutes: {
        root: '/',
        userId: '/:userId'
    }
};
