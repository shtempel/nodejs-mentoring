import { User } from './user.model';

export const models = [
    User
];
