export const DTO_CONSTANTS = {
    users: 'users'
};
