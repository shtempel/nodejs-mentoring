import Sequelize, { WhereOptions } from 'sequelize';

import { ERRORS } from '../constants';
import { DTO_CONSTANTS } from '../dto/constants';
import { DbUser, User, UserToAdd, UserToResponse, UserToUpdate } from '../interfaces/typings';
import { usersToResponse, userToResponse } from '../services/users.parser';
import { User as UserModel } from './../models/user.model';
import { getDbInstance } from './db';

const dbInstance = getDbInstance();
const DEFAULT_OFFSET: number = 0;
const DEFAULT_LIMIT: number = 10;
const OPERATORS = Sequelize.Op;

const getAll = (params: { login?: string, limitParam?: string, offsetParam?: string }): Promise<UserToResponse[]> => {
    const { login, offsetParam, limitParam } = params;
    const offset: number = offsetParam && parseInt(offsetParam, 10) || DEFAULT_OFFSET;
    const limit: number = limitParam && parseInt(limitParam, 10) + offset || DEFAULT_LIMIT;
    const where: WhereOptions = login ? { loginname: { [ OPERATORS.iLike ]: `%${ login }%` } } : {};

    return UserModel
        .findAll({ offset: offset, limit: limit, where })
        .then((data: DbUser[]) => usersToResponse(data));
};

const getUser = (userId: string): Promise<UserToResponse> =>
    UserModel
        .findOne({ where: { user_id: userId } })
        .then((user: DbUser) => user ? userToResponse(user) : null);

const insertUser = async (newUser: UserToAdd, userId: string) => {
    const collection: User[] = await dbInstance.getCollection(DTO_CONSTANTS.users);

    if ( collection.some(existingUser => existingUser.login.toLowerCase() === newUser.login.toLowerCase()) ) {
        throw new Error(`${ newUser.login } ${ ERRORS.userExist }`);
    }

    collection.push({
        userId: userId,
        login: newUser.login,
        password: newUser.password,
        age: newUser.age
    });
};

const updateUser = async (userId: string, userToUpdate: UserToUpdate) => {
    const collection: User[] = await dbInstance.getCollection(DTO_CONSTANTS.users);
    const user: User | undefined = collection.find(collectionItem => collectionItem.userId === userId);

    if ( !user ) {
        throw new Error(ERRORS.userNotFound);
    } else {
        Object.assign(user, userToUpdate);
    }
};

const deleteUser = async (userId: string) => {
    const collection: User[] = await dbInstance.getCollection(DTO_CONSTANTS.users);
    const user: User | undefined = collection.find(collectionItem => collectionItem.userId === userId);

    // if ( user && user.isDeleted || !user ) {
    //     throw new Error(ERRORS.userNotFound);
    // } else {
    //     user.isDeleted = true;
    // }
};

export const userDAL = {
    getAll,
    getUser,
    insertUser,
    updateUser,
    deleteUser
};
