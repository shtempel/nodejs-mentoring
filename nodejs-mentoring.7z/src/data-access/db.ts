import { Sequelize } from 'sequelize-typescript';
import uuid from 'uuid';

import { models } from '../models';
import dbConfig from './../../config/config';
import { User } from '../interfaces/typings';


interface DataBase {
    db: {
        [ key: string ]: User[]
    };
    getCollection: (collection: string) => Promise<any[]>;
}

export const getDbInstance = (): DataBase => DB;

const getDbCollection = async (collection: string): Promise<any[]> => getDbInstance().db[ collection ];

const DB: DataBase = {
    getCollection: getDbCollection,
    db: {
        [ 'users' ]: [
            {
                userId: uuid.v1(),
                login: 'Jake',
                password: 'ewq',
                age: 35
            },
            {
                userId: '123',
                login: 'Kit',
                password: 'qwe',
                age: 35
            },
            {
                userId: uuid.v1(),
                login: 'Nik',
                password: 'qwe',
                age: 35
            },
            {
                userId: uuid.v1(),
                login: 'Bruce',
                password: 'qwe',
                age: 35
            },
            {
                userId: uuid.v1(),
                login: 'John',
                password: 'qwe',
                age: 35
            },
            {
                userId: uuid.v1(),
                login: 'Mike',
                password: 'qwe',
                age: 35
            }
        ]
    }
};

const sequelize = new Sequelize(
    dbConfig.database,
    dbConfig.username,
    dbConfig.password,
    {
        define: { timestamps: false },
        port: dbConfig.port,
        dialect: dbConfig.dialect,
        host: dbConfig.host,
        dialectOptions: { ssl: true },
        pool: dbConfig.pool,
        models: [ ...models ]
    }
);

export const dbConnect = () => {
    return sequelize
        .authenticate()
        .then(() => {
            console.log('Connection has been established successfully!');
        })
        .catch(err => {
            console.error('Unable to connect to the database:', err);
        });
};
